import React from "react";
import { Button as BootstrapButton } from "react-bootstrap";
import PropTypes from "prop-types";

const shapes = {
  square: "rounded-0",
  round: "rounded-3",
};

const variants = {
  outline: {
    teal_400: "border-primary text-primary",
  },
  fill: {
    gray_300_01: "bg-light text-dark",
    teal_400: "bg-primary text-white",
    white_A700: "bg-white text-dark",
  },
};

const sizes = {
  xs: "h-8 px-3 fs-6",
  sm: "h-12 px-5 fs-5",
};

const Button = React.forwardRef(
  (
    {
      children,
      className = "",
      leftIcon,
      rightIcon,
      shape,
      variant = "fill",
      size = "xs",
      color = "teal_400",
      ...restProps
    },
    ref
  ) => {
    return (
      <BootstrapButton
        ref={ref}
        className={`d-flex align-items-center justify-content-center ${className} ${
          shape && shapes[shape]
        } ${
          (variant && variants[variant]?.[color]) || variants[variant]?.[color]
        } ${sizes[size]}`}
        {...restProps}
      >
        {!!leftIcon && leftIcon}
        {children}
        {!!rightIcon && rightIcon}
      </BootstrapButton>
    );
  }
);

Button.propTypes = {
  className: PropTypes.string,
  children: PropTypes.node,
  leftIcon: PropTypes.node,
  rightIcon: PropTypes.node,
  shape: PropTypes.oneOf(["square", "round"]),
  size: PropTypes.oneOf(["xs", "sm"]),
  variant: PropTypes.oneOf(["outline", "fill"]),
  color: PropTypes.oneOf(["gray_300_01", "teal_400", "white_A700"]),
};

export default Button;
