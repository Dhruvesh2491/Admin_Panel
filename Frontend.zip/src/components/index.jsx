import Button from "./Button";
import Img from "./Img";
import Input from "./Input";
import Text from "./Text";
import Heading from "./Heading";

export { Button, Img, Input, Text, Heading };
