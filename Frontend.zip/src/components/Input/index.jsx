import React from "react";
import { Form } from "react-bootstrap";

const shapes = {
  square: "rounded-0",
  round: "rounded-3",
};

const variants = {
  outline: "border border-secondary text-dark",
  fill: "bg-light text-dark",
};

const sizes = {
  xs: "h-10 px-2 fs-6",
  md: "h-12 px-4 fs-6",
  sm: "h-12 px-4 fs-5",
};

const Input = React.forwardRef(
  (
    {
      className = "",
      name = "",
      placeholder = "",
      type = "text",
      label = "",
      prefix,
      suffix,
      onChange,
      shape,
      variant = "fill",
      size = "sm",
      ...restProps
    },
    ref
  ) => {
    return (
      <Form.Group className={`${className} ${shape && shapes[shape]}`}>
        {!!label && <Form.Label>{label}</Form.Label>}
        <div className="d-flex align-items-center">
          {!!prefix && <span className="me-2">{prefix}</span>}
          <Form.Control
            ref={ref}
            type={type}
            name={name}
            placeholder={placeholder}
            onChange={onChange}
            className={`${variant && variants[variant]} ${sizes[size]}`}
            {...restProps}
          />
          {!!suffix && <span className="ms-2">{suffix}</span>}
        </div>
      </Form.Group>
    );
  }
);

export default Input;
