import React from "react";

const sizes = {
  headingxs: "text-[14px] font-semibold",
  headings: "text-[15px] font-semibold",
  headingmd: "text-[16px] font-semibold lg:text-[13px]",
  headinglg: "text-[20px] font-semibold lg:text-[17px]",
  headingxl: "text-[24px] font-bold lg:text-[20px] md:text-[22px]",
  heading2xl:
    "text-[36px] font-bold lg:text-[30px] md:text-[34px] sm:text-[32px]",
};

const Heading = ({
  children,
  className = "",
  size = "headinglg",
  as,
  ...restProps
}) => {
  const Component = as || "h6";
  return (
    <Component
      className={`text-[#000000] font-['Poppins'] ${className} ${sizes[size]}`}
      {...restProps}
    >
      {children}
    </Component>
  );
};

export default Heading;
