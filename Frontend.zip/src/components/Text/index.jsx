import React from "react";

const sizes = {
  textxs: "fs-6",
  texts: "fs-5",
};

const TextComponent = ({
  children,
  className = "",
  as,
  size = "textxs",
  ...restProps
}) => {
  const Component = as || "p";
  return (
    <Component
      className={`text-muted ${className} ${sizes[size]}`}
      {...restProps}
    >
      {children}
    </Component>
  );
};

export default TextComponent;
