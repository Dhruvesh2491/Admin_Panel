import React from "react";
import { Menu, MenuItem, Sidebar, sidebarClasses } from "react-pro-sidebar";
import Heading from "../Heading";

const Sidebar1 = ({ ...props }) => {
  return (
    <Sidebar
      {...props}
      rootStyles={{ [`.${sidebarClasses.container}`]: { gap: 38 } }}
      className={`${props.className} flex-col h-auto px-3.5 my-auto lg:ml-0 md:ml-0 bg-white !sticky overflow-auto md:hidden shadow-none border-none`}
      style={{
        backgroundColor: "#fff",
        borderRadius: "20px",
        width: "20vw",
        margin: "1px 10px 1px 0px", 
      }} 
    >
      <Heading
        size="headingxl"
        as="h4"
        className="text-[24px] font-bold !text-[#199fb1] "
      >
        Logo
      </Heading>
      <Menu
        menuItemStyles={{
          button: {
            padding: "12px",
            color: "#199fb1",
            fontWeight: 600,
            fontSize: "20px",
            borderRadius: "20px",
            [`&:hover,&.ps-active`]: {
              color: "#ffffff",
              backgroundColor: "#199fb1 !important",
            },
          },
        }}
      >
        <MenuItem href="#">Dashboard</MenuItem>
        <MenuItem href="/user">User Management</MenuItem>
        <MenuItem href="#">Rating and Review</MenuItem>
        <MenuItem href="#">Settings</MenuItem>
        <MenuItem href="/history">History</MenuItem>
        <MenuItem href="#">All Bookings</MenuItem>
        <MenuItem href="#">Push Notification</MenuItem>
        <MenuItem href="#">Transaction List</MenuItem>
        <MenuItem href="#">Google Analytics</MenuItem>
        <MenuItem href="#">Multi-Currency</MenuItem>
        <MenuItem href="#">Category</MenuItem>
        <MenuItem href="#">Live Chat History</MenuItem>
        <MenuItem href="#">Package Plan</MenuItem>
        <MenuItem href="#">Referral History</MenuItem>
        <MenuItem href="#">Google Map</MenuItem>
      </Menu>
    </Sidebar>
  );
};

export default Sidebar1;
