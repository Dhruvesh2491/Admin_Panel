import React from "react";
import Img from "../Img";

const Header = ({ ...props }) => {
  return (
    <header
      className={`${props.className} flex sm:flex-col justify-between items-center top-[4%] right-0 left-0 gap-5 mx-36 lg:mx-0 md:mx-0 flex-1 absolute sm:relative `}
      {...props}
    >
        <Img />
    </header>
  );
};

export default Header;
