import React from "react";
import { Helmet } from "react-helmet";
import {
  Container,
  Table,
  Form,
  Button,
  InputGroup,
  Card,
} from "react-bootstrap";
import { FaSearch, FaCog, FaBell } from "react-icons/fa";
import bgImage from "../../assets/images/Vector 1.png";
import Sidebar1 from "../../components/Sidebar1";
import { BsPersonCircle } from "react-icons/bs";

const HistoryPage = () => {
  const historyData = [
    { user: "Yeray Rosalos", action: "Log in", date: "July 3, 2023 12:29 pm" },
    {
      user: "Alan Robert",
      action: "Booked Product",
      date: "July 3, 2023 12:27 pm",
    },
    {
      user: "Yeray Rosalos",
      action: "Selling Product",
      date: "July 3, 2023 12:29 pm",
    },
    { user: "Alan Robert", action: "Commented", date: "July 3, 2023 12:27 pm" },
    {
      user: "Yeray Rosalos",
      action: "Bought Product",
      date: "July 3, 2023 12:29 pm",
    },
    { user: "Alan Robert", action: "Log out", date: "July 3, 2023 12:27 pm" },
  ];

  return (
    <>
      <Helmet>
        <title>Activity History</title>
        <meta name="description" content="User activity history" />
      </Helmet>
      <div
        className="d-flex min-vh-100 w-100 align-items-center justify-content-center"
        style={{
          backgroundImage: `url(${bgImage})`,
          backgroundSize: "contain",
          backgroundPosition: "top center",
          backgroundRepeat: "no-repeat",
          backgroundColor: "#fff",
          minHeight: "100vh",
        }}
      >
        <div
          style={{
            marginTop: "50px",
            marginBottom: "50px",
            display: "flex",
            alignItems: "flex-start",
          }}
        >
          <Sidebar1
            style={{
              position: "relative",
              zIndex: 10,
              backgroundColor: "#fff",
              borderRadius: "20px",
              width: "20vw",
            }}
          />
        </div>

        <div className="main" style={{ marginTop: "0px" }}>
          <div
            className="d-flex justify-content-between align-items-center"
            style={{
              width: "50vw",
              padding: "10px 0",
              marginBottom: "10px",
            }}
          >
            <InputGroup className="me-3" style={{ width: "40%" }}>
              <Form.Control placeholder="Search by user, date, or activity type" />
              <Button variant="primary" style={{ backgroundColor: "#199FB1" }}>
                <FaSearch />
              </Button>
            </InputGroup>

            <div className="d-flex align-items-center" style={{ gap: "20px" }}>
              {/* Notification Bell */}
              <FaBell size={24} color="#199FB1" style={{ cursor: "pointer" }} />

              <BsPersonCircle
                size={30}
                color="#199FB1"
                style={{ cursor: "pointer" }}
              />
            </div>
          </div>

          <hr
            style={{
              border: "3px solid #199FB1",
              width: "50vw",
              marginBottom: "20px",
            }}
          />

          <Container
            className="bg-white p-4 shadow rounded"
            style={{
              position: "relative",
              zIndex: 10,
              width: "50vw",
            }}
          >
            <div
              style={{
                display: "flex",
                flexDirection: "row",
                justifyContent: "space-between",
              }}
            >
              <div className="">
                <h5>Activity History</h5>
                <p style={{ fontSize: "10px", color: "#199FB1" }}>
                  View historical data of actions taken within the app.
                </p>
              </div>
              <InputGroup
                className="mb-3"
                style={{ width: "40%", height: "20px" }}
              >
                <Form.Control placeholder="Search by user, date, or activity type" />
                <Button
                  variant="primary"
                  style={{ backgroundColor: "#199FB1" }}
                >
                  <FaSearch />
                </Button>
              </InputGroup>
            </div>
            
            <Table striped bordered hover responsive>
              <thead>
                <tr>
                  <th>
                    <Form.Check type="checkbox" />
                  </th>
                  <th>User</th>
                  <th>Action</th>
                  <th>Date & Time</th>
                  <th>React</th>
                </tr>
              </thead>
              <tbody>
                {historyData.map((entry, index) => (
                  <tr key={index}>
                    <td>
                      <Form.Check type="checkbox" />
                    </td>
                    <td>{entry.user}</td>
                    <td>{entry.action}</td>
                    <td>{entry.date}</td>
                    <td style={{ color: "#199FB1" }}>...</td>
                  </tr>
                ))}
              </tbody>
            </Table>

            <div className="d-flex justify-content-between mt-3">
              <Button variant="white">Delete</Button>
              <div>
                <Button variant="light">First</Button>{" "}
                <Button variant="light">1</Button>{" "}
                <Button variant="light">2</Button>{" "}
                <Button variant="light">3</Button>{" "}
                <Button variant="light">Last</Button>
              </div>
            </div>

          </Container>
          <div className="text-center mt-3">
            <p style={{ color: "#199FB1" }} variant="outline-primary">
              Export activity log to CSV
            </p>
          </div>
        </div>
      </div>
    </>
  );
};

export default HistoryPage;
