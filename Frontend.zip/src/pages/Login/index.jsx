import React, { useState } from "react";
import { Button } from "react-bootstrap";
import { Helmet } from "react-helmet";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import bgImage from "../../assets/images/img_login.png";
import icon from "../../assets/images/img_whatsapp_image_2024_07_03.png";
import { Img, Input } from "../../components";
import Text from "../../components/Text";
import { loginUser } from "../../redux/userSlice";

const Login = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { status, error } = useSelector((state) => state.user);
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.email || !formData.password) {
      toast.error("All fields are required!");
      return;
    }

    try {
      const resultAction = await dispatch(loginUser(formData));

      if (loginUser.fulfilled.match(resultAction)) {
        toast.success("Login successful!");
        setTimeout(() => {
          navigate("/welcome");
        }, 1000);
      } else {
        const errorMessage =
          resultAction.payload?.message || "Invalid email or password!";
        toast.error(errorMessage);
      }
    } catch (error) {
      toast.error("An unexpected error occurred!");
    }
  };

  return (
    <>
      <Helmet>
        <title>Free Shops App</title>
        <meta name="description" content="Free shops App controller login" />
      </Helmet>

      <ToastContainer position="top-right" autoClose={3000} hideProgressBar />

      <div
        className="flex min-h-screen w-full items-center justify-center bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `url(${bgImage})`,
          backgroundColor: "#fff",
          width: "100vw",
          height: "100vh",
        }}
      >
        <div className="container mx-auto px-4">
          <div className="flex w-full">
            <div
              style={{
                marginTop: "100px",
                backgroundColor: "#e7e7e7",
                width: "80vw",
                height: "75vh",
                justifyContent: "space-around",
                borderRadius: "30px",
              }}
            >
              <div
                className="flex w-full max-w-6xl bg-gray-300 rounded-[20px] p-6 shadow-lg"
                style={{
                  display: "flex",
                  flexDirection: "row",
                  justifyContent: "space-evenly",
                  width: "80vw",
                  height: "75vh",
                  borderRadius: "30px",
                }}
              >
               
                <div className="flex flex-1 items-center justify-center relative md:w-full">
                  <div
                    className="flex"
                    style={{
                      width: "35vw",
                      marginTop: "180px",
                      marginLeft: "50px",
                    }}
                  >
                    <Img
                      src={icon}
                      alt="Free Shops Logo"
                      className="h-[248px] w-[248px] object-contain"
                    />
                  </div>
                </div>

                <div style={{ width: "60vw", marginLeft: "120px" }}>
                  <div
                    style={{
                      width: "30vw",
                      marginTop: "60px",
                      borderRadius: "30px",
                      height: "60vh",
                      padding: "20px",
                    }}
                    className="flex w-[58%] flex-col items-start justify-center rounded-[20px] bg-white px-[50px] py-[38px] md:w-full md:px-5 sm:py-4"
                  >
                    <Text
                      size="heading2xl"
                      as="h1"
                      className="text-[36px] font-bold"
                    >
                      Log in
                    </Text>

                    <Text
                      size="text2xs"
                      as="p"
                      className="text-[14px] font-normal"
                    >
                      Welcome to Free shops App controller
                    </Text>

                    <div className="mt-[78px] flex w-full flex-col items-start">
                      <Text
                        size="headingxs"
                        as="h5"
                        className="text-left self-start text-[14px] font-semibold ms-5"
                        style={{
                          marginTop: "30px",
                          display: "flex",
                          flow: "left",
                        }}
                      >
                        User Name
                      </Text>
                      <Input
                        color="gray_600_01"
                        size="md"
                        variant="outline"
                        shape="round"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        placeholder="XYZ"
                        className="w-full rounded-[10px] !border px-5 font-['Roboto']"
                      />
                    </div>

                    <div className="mt-[34px] flex w-full flex-col items-start">
                      <Text
                        size="headingxs"
                        as="h5"
                        className="self-start text-[14px] font-semibold ms-5"
                        style={{
                          marginTop: "30px",
                          display: "flex",
                          flow: "left",
                        }}
                      >
                        Password
                      </Text>
                      <div className="relative w-full">
                        <Input
                          color="gray_600_01"
                          size="md"
                          variant="outline"
                          shape="round"
                          name="password"
                          value={formData.password}
                          onChange={handleChange}
                          type="password"
                          placeholder="0987532345"
                          className="w-full rounded-[10px] !border px-5 font-['Roboto']"
                        />
                      </div>
                    </div>

                    <a
                      href="#"
                      className="mt-[18px]"
                      style={{ textDecoration: "none" }}
                    >
                      <Text size="textxs" as="p" className="mt-3">
                        Forgot Password
                      </Text>
                    </a>

                    <a href="#" target="_blank">
                      <Button
                        size="sm"
                        shape="round"
                        className="mt-7 min-w-[124px] px-8 sm:px-4 font-bold"
                        style={{
                          backgroundColor: "#23a6ac",
                          width: "150px",
                          height: "50px",
                          borderRadius: "15px",
                        }}
                        onClick={handleSubmit}
                        disabled={status === "loading"}
                      >
                        {status === "loading" ? "Creating..." : "Login"}
                      </Button>
                    </a>

                    <a
                      href="/register"
                      style={{ textDecoration: "none", marginTop: "100px" }}
                    >
                      <Text as="p" className="mt-3 ">
                        Create New Account
                      </Text>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Login;
