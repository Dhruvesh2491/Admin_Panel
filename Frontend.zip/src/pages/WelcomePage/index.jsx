import React from "react";
import { Img } from "../../components";
import { Helmet } from "react-helmet";
import bgImage from "../../assets/images/img_login.png";
import icon from "../../assets/images/img_whatsapp_image_2024_07_03.png";
import { Button } from "react-bootstrap";

const WelcomePage = () => {
  return (
    <>
      <Helmet>
        <title>Free Shops App</title>
        <meta name="description" content="Free shops App controller login" />
      </Helmet>
      <div
        className="flex min-h-screen w-full items-center justify-center bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `url(${bgImage})`,
          backgroundColor: "#fff",
          width: "100vw",
          height: "100vh",
        }}
      >
        <div className="container mx-auto px-4 flex justify-center items-center">
          <div
            className="flex w-full"
            style={{
              marginTop: "100px",
              backgroundColor: "#e7e7e7",
              width: "80vw",
              height: "75vh",
              justifyContent: "center", 
              alignItems: "center",
              borderRadius: "30px",
              padding: "20px",
            }}
          >
            
            <div
              className="flex flex-col justify-center items-center text-center"
              style={{
                width: "100%",
                height: "100%", 
              }}
            >
              <div
                className="flex justify-center"
                style={{
                  width: "35vw",
                  marginTop: "50px",
                  marginLeft:"315px"
                }}
              >
                <Img
                  src={icon}
                  alt="Free Shops Logo"
                  className="h-[248px] w-[248px] object-contain"
                />
              </div>
              <h1 className="mt-4" style={{fontSize:"55px"}}>Welcome</h1>
              <h4 className="mt-2">to the Free Shops App Admin Panel</h4>
              <h4 className="mt-2">
                Manage and monitor all aspects of your app seamlessly from one
                place. Use the tools below to get started.
              </h4>
              <a href="/user" target="_blank">
                <Button
                  size="sm"
                  shape="round"
                  className="mt-4 px-8 font-bold"
                  style={{
                    backgroundColor: "#23a6ac",
                    width: "150px",
                    height: "50px",
                    borderRadius: "15px",
                  }}
                >
                  Get Started
                </Button>
              </a>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default WelcomePage;
