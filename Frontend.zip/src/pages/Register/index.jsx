import React, { useEffect, useState } from "react";
import { Button } from "react-bootstrap";
import { Helmet } from "react-helmet";
import bgImage from "../../assets/images/img_login.png";
import icon from "../../assets/images/img_whatsapp_image_2024_07_03.png";
import { Img, Input } from "../../components";
import Text from "../../components/Text";
import { useDispatch, useSelector } from "react-redux";
import { registerUser, resetAuthState } from "../../redux/userSlice";
import { useNavigate } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const Register = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  // const { status } = useSelector((state) => state.user);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    password: "",
    confirmPassword: "",
  });

  const { isLoading, error, successMessage } = useSelector(
    (state) => state.user
  );

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    dispatch(registerUser(formData));
  };

  useEffect(() => {
    if (error) {
      toast.error(error);
      dispatch(resetAuthState());
    }
    if (successMessage) {
      toast.success(successMessage);
      dispatch(resetAuthState());
      setTimeout(() => {
        navigate("/");
      }, 1000);
    }
  }, [error, successMessage, dispatch]);

  return (
    <>
      <Helmet>
        <title>Free Shops App</title>
        <meta name="description" content="Free shops App controller login" />
      </Helmet>

      <div
        className="flex min-h-screen w-full items-center justify-center bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `url(${bgImage})`,
          backgroundColor: "#fff",
          width: "100vw",
          height: "100vh",
        }}
      >
        <div className="container mx-auto px-4">
          <div className="flex w-full">
          
            <div
              style={{
                marginTop: "10px", 
                backgroundColor: "#e7e7e7",
                width: "80vw",
                height: "95vh",
                justifyContent: "space-around",
                borderRadius: "30px",
              }}
            >
              <div
                className="flex w-full max-w-6xl bg-gray-300 rounded-[20px] p-6 shadow-lg"
                style={{
                  display: "flex",
                  flexDirection: "row",
                  justifyContent: "space-evenly",
                  width: "80vw",
                  height: "95vh",
                  borderRadius: "30px",
                }}
              >
              
                <div className="flex flex-1 items-center justify-center relative md:w-full">
                  <div
                    className="flex"
                    style={{
                      width: "35vw",
                      marginTop: "180px",
                      marginLeft: "50px",
                    }}
                  >
                    <Img
                      src={icon}
                      alt="Free Shops Logo"
                      className="h-[248px] w-[248px] object-contain"
                    />
                  </div>
                </div>

                <div style={{ width: "60vw", marginLeft: "120px" }}>
                  <div
                    style={{
                      width: "30vw",
                      marginTop: "60px",
                      borderRadius: "30px",
                      height: "80vh",
                      padding: "20px",
                    }}
                    className="flex w-[58%] flex-col items-start justify-center rounded-[20px] bg-white px-[50px] py-[38px] md:w-full md:px-5 sm:py-4"
                  >
                    <Text
                      size="heading2xl"
                      as="h1"
                      className="text-[36px] font-bold"
                    >
                      Create New Account
                    </Text>

                    <Text
                      size="text2xs"
                      as="p"
                      className="text-[14px] font-normal"
                    >
                      Welcome to Free shops App controller
                    </Text>

                    <div className="mt-[78px] flex w-full flex-col items-start">
                      <Text
                        size="headingxs"
                        as="h5"
                        className="text-left self-start text-[14px] font-semibold ms-5"
                        style={{
                          marginTop: "10px",
                          display: "flex",
                          flow: "left",
                        }}
                      >
                        User Name
                      </Text>
                      <Input
                        color="gray_600_01"
                        size="md"
                        variant="outline"
                        shape="round"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        className="w-full rounded-[10px] !border px-5 font-['Roboto']"
                      />
                    </div>
                    <div className="mt-[78px] flex w-full flex-col items-start">
                      <Text
                        size="headingxs"
                        as="h5"
                        className="text-left self-start text-[14px] font-semibold ms-5"
                        style={{
                          marginTop: "10px",
                          display: "flex",
                          flow: "left",
                        }}
                      >
                        Email
                      </Text>
                      <Input
                        color="gray_600_01"
                        size="md"
                        variant="outline"
                        shape="round"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        className="w-full rounded-[10px] !border px-5 font-['Roboto']"
                      />
                    </div>
                    <div className="mt-[78px] flex w-full flex-col items-start">
                      <Text
                        size="headingxs"
                        as="h5"
                        className="text-left self-start text-[14px] font-semibold ms-5"
                        style={{
                          marginTop: "10px",
                          display: "flex",
                          flow: "left",
                        }}
                      >
                        Phone Number
                      </Text>
                      <Input
                        color="gray_600_01"
                        size="md"
                        variant="outline"
                        shape="round"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        className="w-full rounded-[10px] !border px-5 font-['Roboto']"
                      />
                    </div>

                    <div className="mt-[34px] flex w-full flex-col items-start">
                      <Text
                        size="headingxs"
                        as="h5"
                        className="self-start text-[14px] font-semibold ms-5"
                        style={{
                          marginTop: "10px",
                          display: "flex",
                          flow: "left",
                        }}
                      >
                        Password
                      </Text>
                      <div className="relative w-full">
                        <Input
                          color="gray_600_01"
                          size="md"
                          variant="outline"
                          shape="round"
                          type="password"
                          name="password"
                          value={formData.password}
                          onChange={handleChange}
                          className="w-full rounded-[10px] !border px-5 font-['Roboto']"
                        />
                      </div>
                    </div>
                    <div className="mt-[34px] flex w-full flex-col items-start">
                      <Text
                        size="headingxs"
                        as="h5"
                        className="self-start text-[14px] font-semibold ms-5"
                        style={{
                          marginTop: "10px",
                          display: "flex",
                          flow: "left",
                        }}
                      >
                        Confirm Password
                      </Text>
                      <div className="relative w-full">
                        <Input
                          color="gray_600_01"
                          size="md"
                          variant="outline"
                          shape="round"
                          name="confirmPassword"
                          value={formData.confirmPassword}
                          onChange={handleChange}
                          type="password"
                          className="w-full rounded-[10px] !border px-5 font-['Roboto']"
                        />
                      </div>
                    </div>

                    <a href="#" target="_blank">
                      <Button
                        size="sm"
                        shape="round"
                        className="mt-3  px-8 font-bold"
                        style={{
                          backgroundColor: "#23a6ac",
                          width: "150px",
                          height: "50px",
                          borderRadius: "15px",
                        }}
                        onClick={handleSubmit}
                      >
                        {isLoading ? "Registering..." : "Register"}
                      </Button>
                    </a>

                    <a
                      href="/"
                      style={{ textDecoration: "none", marginTop: "100px" }}
                    >
                      <Text as="p" className="mt-3 ">
                        Already have an account?
                      </Text>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <ToastContainer
        position="top-right"
        autoClose={1000}
        hideProgressBar={false}
      />
    </>
  );
};

export default Register;
