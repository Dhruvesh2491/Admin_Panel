import React, { useState } from "react";
import { Helmet } from "react-helmet";
import {
  Container,
  Table,
  Form,
  Button,
  InputGroup,
  Card,
} from "react-bootstrap";
import { FaSearch, FaCog, FaBell } from "react-icons/fa";
import bgImage from "../../assets/images/Vector 1.png";
import Sidebar1 from "../../components/Sidebar1";
import { BsPersonCircle, BsThreeDotsVertical } from "react-icons/bs";

const UserManagement = () => {
  const userData = [
    {
      name: "Yeray Rosalos",
      email: "yerayrosales@gmail.com",
      phone: "+91-98785432",
      sold: 2,
      bought: 1,
      status: "Block",
      rating: 3,
    },
    {
      name: "Talah Cotton",
      email: "talahcotton@gmail.com",
      phone: "+91-98765432",
      sold: 0,
      bought: 5,
      status: "Unblock",
      rating: 4,
    },
    {
      name: "Yeray Rosalos",
      email: "yerayrosales@gmail.com",
      phone: "+91-98785432",
      sold: 2,
      bought: 1,
      status: "Block",
      rating: 3,
    },
    {
      name: "Talah Cotton",
      email: "talahcotton@gmail.com",
      phone: "+91-98765432",
      sold: 0,
      bought: 5,
      status: "Unblock",
      rating: 4,
    },
    {
      name: "Talah Cotton",
      email: "talahcotton@gmail.com",
      phone: "+91-98765432",
      sold: 0,
      bought: 5,
      status: "Unblock",
      rating: 4,
    },
    {
      name: "Talah Cotton",
      email: "talahcotton@gmail.com",
      phone: "+91-98765432",
      sold: 0,
      bought: 5,
      status: "Unblock",
      rating: 4,
    },
    {
      name: "Talah Cotton",
      email: "talahcotton@gmail.com",
      phone: "+91-98765432",
      sold: 0,
      bought: 5,
      status: "Unblock",
      rating: 4,
    },
  ];

  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 4;

  const totalPages = Math.ceil(userData.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentUsers = userData.slice(startIndex, endIndex);

  return (
    <>
      <Helmet>
        <title>Activity History</title>
        <meta name="description" content="User activity history" />
      </Helmet>
      <div
        className="d-flex min-vh-100 w-100 align-items-center justify-content-center"
        style={{
          backgroundImage: `url(${bgImage})`,
          backgroundSize: "contain",
          backgroundPosition: "top center",
          backgroundRepeat: "no-repeat",
          backgroundColor: "#fff",
          minHeight: "100vh",
        }}
      >
        <div
          style={{
            marginTop: "50px",
            marginBottom: "50px",
            display: "flex",
            alignItems: "flex-start",
          }}
        >
          <Sidebar1
            style={{
              position: "relative",
              zIndex: 10,
              backgroundColor: "#fff",
              borderRadius: "20px",
              width: "20vw",
            }}
          />
        </div>

        <div className="main">
          <div
            className="d-flex justify-content-between align-items-center"
            style={{
              width: "60vw",
              padding: "10px 0",
              marginBottom: "10px",
            }}
          >
            <InputGroup className="me-3" style={{ width: "40%" }}>
              <Form.Control placeholder="Search by user, date, or activity type" />
              <Button variant="primary" style={{ backgroundColor: "#199FB1" }}>
                <FaSearch />
              </Button>
            </InputGroup>

            <div className="d-flex align-items-center" style={{ gap: "20px" }}>
              {/* Notification Bell */}
              <FaBell size={24} color="#199FB1" style={{ cursor: "pointer" }} />

              <BsPersonCircle
                size={30}
                color="#199FB1"
                style={{ cursor: "pointer" }}
              />
            </div>
          </div>

          <hr
            style={{
              border: "3px solid #199FB1",
              width: "50vw",
              marginBottom: "20px",
            }}
          />

          <Container
            className="bg-white p-4 shadow rounded"
            style={{
              position: "relative",
              zIndex: 10,
              width: "60vw",
            }}
          >
            <InputGroup
              style={{ width: "50%", height: "20px", marginBottom: "40px" }}
            >
              <Form.Control placeholder="Search by user, date, or activity type" />
              <Button variant="primary" style={{ backgroundColor: "#199FB1" }}>
                <FaSearch />
              </Button>
            </InputGroup>

            {/* Table */}
            <Table striped bordered hover responsive className="shadow-sm">
              <thead>
                <tr>
                  <th>
                    <Form.Check type="checkbox" />
                  </th>
                  <th>Name</th>
                  <th>User Deal</th>
                  <th>Block / Unblock</th>
                  <th>Ratings</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {currentUsers.map((user, index) => (
                  <tr key={index}>
                    <td>
                      <Form.Check type="checkbox" />
                    </td>
                    <td>
                      <strong>{user.name}</strong>
                      <br />
                      <span style={{ fontSize: "12px", color: "#777" }}>
                        {user.email}
                        <br />
                        {user.phone}
                      </span>
                    </td>
                    <td>
                      <span style={{ color: "red" }}>{user.sold} Sold</span>
                      <br />
                      <span style={{ color: "green" }}>
                        {user.bought} Bought
                      </span>
                    </td>
                    <td>
                      <Button
                        variant={
                          user.status === "Block" ? "outline-warning" : "danger"
                        }
                        size="sm"
                      >
                        {user.status}
                      </Button>
                    </td>
                    <td>
                      {"⭐".repeat(user.rating)} {"☆".repeat(5 - user.rating)}
                    </td>
                    <td>
                      <BsThreeDotsVertical size={20} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>

            {/* Pagination */}
            <div className="d-flex justify-content-between mt-3">
              <Button variant="white">Delete</Button>
              <div>
                <Button
                  variant="light"
                  onClick={() => setCurrentPage(1)}
                  disabled={currentPage === 1}
                >
                  First
                </Button>{" "}
                <Button
                  variant="light"
                  onClick={() => setCurrentPage(currentPage - 1)}
                  disabled={currentPage === 1}
                >
                  Prev
                </Button>{" "}
                {Array.from({ length: totalPages }, (_, i) => (
                  <Button
                    key={i}
                    variant={currentPage === i + 1 ? "primary" : "light"}
                    onClick={() => setCurrentPage(i + 1)}
                  >
                    {i + 1}
                  </Button>
                ))}{" "}
                <Button
                  variant="light"
                  onClick={() => setCurrentPage(currentPage + 1)}
                  disabled={currentPage === totalPages}
                >
                  Next
                </Button>{" "}
                <Button
                  variant="light"
                  onClick={() => setCurrentPage(totalPages)}
                  disabled={currentPage === totalPages}
                >
                  Last
                </Button>
              </div>
            </div>

            {/* Export Button */}
          </Container>
          <div className="text-center mt-3">
            <p style={{ color: "#199FB1" }} variant="outline-primary">
              Export activity log to CSV
            </p>
          </div>
        </div>
      </div>
    </>
  );
};

export default UserManagement;
