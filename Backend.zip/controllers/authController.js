import jwt from "jsonwebtoken";
import User from "../models/user.js";
import bcrypt from "bcrypt";
import dotenv from "dotenv";

dotenv.config(); // Load environment variables

export const registerUser = async (req, res) => {
  try {
    const user = await User.create(req.body);
    res.status(201).send({ message: "Registration Success", user });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// Login user
export const loginUser = async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.status(401).json({ error: "Invalid credentials" });
    }
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET);
    res.status(200).send({ message: "Login Success", token });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};
