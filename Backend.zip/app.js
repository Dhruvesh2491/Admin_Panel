import express from "express";
import cors from "cors";
import connectDB from "./config/db.js";
import authRoutes from "./routes/user.js";
import dotenv from "dotenv";

dotenv.config();
const port = process.env.PORT;

const app = express();

// Middleware
app.use(express.json());
app.use(cors());

// Routes
app.use("/api/auth", authRoutes);

// Connect to DB and start the server
connectDB();

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
